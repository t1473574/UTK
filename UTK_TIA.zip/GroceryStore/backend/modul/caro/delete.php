<?php
    $id = $_GET ['idcar'];
    $b = $conn->prepare("DELETE FROM tb_caro WHERE idcaro = '$id'");
    if($b->execute()){
        header('location:?page=caro');
    }
?>