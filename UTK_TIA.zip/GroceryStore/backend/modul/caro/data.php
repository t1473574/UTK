<!-- Dashboard Heading -->
<div class="p-4" style="flex-grow: 1; background-color: #f8f9fa; min-height: 100vh;">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0" style="color: #12606e; font-weight: 500;">
      <i class="fas fa-images me-2"></i>Kelola Carousel
    </h4>
    <a href="?page=addcaro" class="btn text-white" style="background-color: #12606e;">
      <i class="fas fa-plus me-1"></i> Tambah Carousel
    </a>
  </div>

  <!-- Table -->
  <div class="card shadow-sm border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover align-middle text-center">
          <thead class="table-light">
            <tr>
              <th style="width: 5%;">Id</th>
              <th style="width: 25%;">Image</th>
              <th style="width: 25%;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $sqlOut = $conn->prepare("SELECT * FROM tb_caro");
              $sqlOut->execute();
              $no = 1;
              foreach ($sqlOut as $row) {
            ?>
              <tr>
                <td class="fw-semibold"><?= $no++ ?></td>
                <td>
                  <img src="../gbrproject/<?= $row['img_url'] ?>" alt="Image" class="img-thumbnail rounded shadow-sm" style="width: 120px; height: auto;">
                </td>
                <td>
                  <a href="?page=editcaro&idcar=<?= $row['idcaro'] ?>" class="btn btn-sm btn-outline-warning me-2">
                    <i class="fas fa-edit me-1"></i> Edit
                  </a>
                  <a href="?page=deletecaro&idcar=<?= $row['idcaro'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Yakin ingin menghapus gambar ini?')">
                    <i class="fas fa-trash me-1"></i> Hapus
                  </a>
                </td>
              </tr>
            <?php } ?>
            <?php if ($sqlOut->rowCount() == 0): ?>
              <tr>
                <td colspan="3" class="text-muted">Belum ada data carousel.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
