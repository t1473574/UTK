<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header text-white" style="background-color: #12606e;">
            <h5 class="mb-0"><i class="fas fa-plus me-2"></i> Tambah Gambar Carousel</h5>
        </div>
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label fw-bold">Pilih Gambar</label>
                    <input type="file" name="gbr" class="form-control" required>
                    <small class="form-text text-muted">Format gambar: JPG, PNG, atau JPEG</small>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="?page=caro" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Kembali
                    </a>
                    <button type="submit" name="btn" class="btn text-white" style="background-color: #12606e;">
                        <i class="fas fa-upload me-1"></i> Upload Gambar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
if (isset($_POST['btn'])) {
    $path = '../gbrproject/';
    $gbr = $_FILES['gbr']['name'];

    if ($gbr != "") {
        if (move_uploaded_file($_FILES['gbr']['tmp_name'], $path . $gbr)) {
            $sqlinput = $conn->prepare('INSERT INTO tb_caro(img_url) VALUES(:img)');
            $sqlinput->bindParam(':img', $gbr);
            if ($sqlinput->execute()) {
                echo "<script>window.location.href='?page=caro';</script>";
                exit();
            } else {
                echo "<div class='alert alert-danger mt-3'>❌ Gagal menambahkan data: " . $sqlinput->errorInfo()[2] . "</div>";
            }
        } else {
            echo "<div class='alert alert-danger mt-3'>❌ Upload gambar gagal. Pastikan folder <code>gbrproject</code> memiliki izin tulis.</div>";
        }
    } else {
        echo "<div class='alert alert-warning mt-3'>⚠️ Silakan pilih gambar terlebih dahulu.</div>";
    }
}
?>
