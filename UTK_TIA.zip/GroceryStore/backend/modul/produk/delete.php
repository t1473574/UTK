<?php
    $id = $_GET ['idpro'];
    $b = $conn->prepare("DELETE FROM tb_produk WHERE idproduk = '$id'");
    if($b->execute()){
        header('location:?page=produk');
     }
?>
