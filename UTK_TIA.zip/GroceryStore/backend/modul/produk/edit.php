<?php
$id = $_GET['idpro'];
$b = $conn->prepare("SELECT * FROM tb_produk WHERE idproduk = :id");
$b->bindParam(':id', $id);
$b->execute();
$result = $b->fetch(PDO::FETCH_ASSOC);
?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header text-white" style="background-color: #12606e;">
            <h5 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Product</h5>
        </div>
        <div class="card-body">
            <!-- Formulir untuk mengedit gambar -->
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $result['idproduk'] ?>">

                <!-- Menampilkan title saat ini -->
                <div class="mb-3">
                    <input class="form-control" type="text" name="jdl" value="<?php echo $result['nama']?>">
                </div>

                <div class="mb-3">
                <select name="ktgr" id="kategori" class="form-control mb-3">
                <?php 
                $sqlkat = $conn->prepare("SELECT*FROM tb_kate");
                $sqlkat->execute();
                foreach ($sqlkat as $kate) {
                    ?>
                    <option value="<?=$kate['idkate']; ?>"><?=$kate['title']?>
                    <?php
                }
                ?>
                </div>

                <div class="mb-3">
                <input class="form-control" type="text" name="hrg" value="<?php echo $result['harga']?>">
                </div>

                <!-- Menampilkan gambar saat ini -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Gambar Saat Ini:</label><br>
                    <img src="../gbrproject/<?= $result['img'] ?>" width="180" class="rounded shadow-sm mb-2" alt="Current Image">
                </div>

                <!-- Upload gambar baru -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Upload Gambar Baru (opsional):</label>
                    <input type="file" class="form-control" name="img">
                </div>

                <!-- Tombol navigasi dan submit -->
                <div class="d-flex justify-content-between">
                    <a href="?page=produk" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Kembali
                    </a>
                    <button name="btn" type="submit" class="btn text-white" style="background-color: #12606e;">
                        <i class="fas fa-save me-1"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$id = $_GET['idpro'];

// Ambil data produk dari database
$stmt = $conn->prepare("SELECT * FROM tb_produk WHERE idproduk = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Proses update saat tombol disubmit
if (isset($_POST['btn'])) {
    $path = '../gbrproject/';
    $id     = $_POST['id'];
    $jdl    = $_POST['jdl'];
    $hrg    = $_POST['hrg'];
    $ktgr   = $_POST['ktgr'];
    $img    = $_FILES['img']['name'];
    $imgOld = $result['img'];

    // Jika gambar baru diupload
    if (!empty($img)) {
        move_uploaded_file($_FILES['img']['tmp_name'], $path.$img);
        $query = $conn->prepare("
            UPDATE tb_produk 
            SET nama = :jdl, harga = :hrg, idkate = :ktgr, img = :img 
            WHERE idproduk = :id
        ");
        $query->bindParam(':img', $img);
    } else {
        // Pakai gambar lama
        $query = $conn->prepare("
            UPDATE tb_produk 
            SET nama = :jdl, harga = :hrg, idkate = :ktgr 
            WHERE idproduk = :id
        ");
    }

    // Bind parameter umum
    $query->bindParam(':id', $id);
    $query->bindParam(':jdl', $jdl);
    $query->bindParam(':hrg', $hrg);
    $query->bindParam(':ktgr', $ktgr);

    if ($query->execute()) {
        echo "<script>window.location.href='?page=produk';</script>";
        exit();
    } else {
        echo "<div class='alert alert-danger mt-3'>❌ Gagal update data.</div>";
    }
}
?>
