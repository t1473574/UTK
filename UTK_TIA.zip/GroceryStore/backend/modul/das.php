<?php
$username = $_SESSION['username'] ?? 'Guest'; // Cek apakah username ada, jika tidak tampilkan 'Guest'

//total produk
$stmtTotalProduk = $conn->query("SELECT COUNT(*) AS total FROM tb_produk");
$totalProduk = $stmtTotalProduk->fetch(PDO::FETCH_ASSOC)['total'];

// Total penghasilan
$stmtTotalPenghasilan = $conn->query("SELECT SUM(total) AS total FROM tb_order");
$totalPenghasilan = $stmtTotalPenghasilan->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
$totalPenghasilan = number_format($totalPenghasilan, 0, ',', '.');


// Total user
$stmtTotalUser = $conn->query("SELECT COUNT(*) AS total FROM tb_user");
$totalUser = $stmtTotalUser->fetch(PDO::FETCH_ASSOC)['total'];

// Total order 
$stmtTotalOrder = $conn->query("SELECT COUNT(*) AS total FROM tb_order");
$totalOrder = $stmtTotalOrder->fetch(PDO::FETCH_ASSOC)['total'];
?>

  <div class="card shadow-sm border-0">
    <div class="card-body">
      <h1 class="fw-bold mb-3" style="color: rgb(24, 147, 165);">
        Hai, <?= htmlspecialchars($username) ?>! 👋
      </h1>
      <p class="lead">Selamat datang di halaman dashboard. Silakan pilih menu di sidebar untuk mulai mengelola konten toko.</p>
      <hr>

<!-- Ringkasan singkat atau statistik -->
<div class="row mt-4">
  <div class="col-md-3 mb-3">
    <div class="card text-white" style="background-color: #1893a5;">
      <div class="card-body">
        <h5 class="card-title">Total Produk</h5>
        <p class="card-text fs-4"><?= $totalProduk ?></p>
      </div>
    </div>
  </div>

  <div class="col-md-3 mb-3">
  <div class="card text-white" style="background-color: #28a745;">
    <div class="card-body">
      <h5 class="card-title">Total Penghasilan</h5>
      <p class="card-text fs-4">Rp <?= $totalPenghasilan ?></p>
    </div>
  </div>
</div>


  <div class="col-md-3 mb-3">
    <div class="card text-white" style="background-color: #ffc107;">
      <div class="card-body">
        <h5 class="card-title">Total User</h5>
        <p class="card-text fs-4"><?= $totalUser ?></p>
      </div>
    </div>
  </div>

  <div class="col-md-3 mb-3">
    <div class="card text-white" style="background-color: #dc3545;">
      <div class="card-body">
        <h5 class="card-title">Total Order</h5>
        <p class="card-text fs-4"><?= $totalOrder ?></p>
      </div>
    </div>
  </div>


