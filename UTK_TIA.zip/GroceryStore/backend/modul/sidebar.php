<!-- Sidebar -->
<!-- <?php session_start(); ?> -->
<div class="wrapper" style="display: flex;">
<div class="sidebar text-white p-3" style="width: 250px; min-height: 100vh;">
    <div style="font-family: font1;" class="mb-4 mt-4">
        <h3>Admin Dashboard</h3>
        <h4 class="text-center me-3">Grocery Store</h4>
    </div>

    <hr style="background-color: black; height: 2px;">

    <!-- Sidebar nav -->
    <ul class="nav flex-column">
        <li class="nav-item mb-4">
            <a href="?page=dashboard" class="text-white text-decoration-none">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item mb-4">
            <a href="?page=caro" class="text-white text-decoration-none">
                <i class="fas fa-images me-2"></i> Carousel
            </a>
        </li>
        <li class="nav-item mb-4">
            <a href="?page=kate" class="text-white text-decoration-none">
                <i class="fas fa-list me-2"></i> Kategori
            </a>
        </li>
        <li class="nav-item mb-4">
            <a href="?page=produk" class="text-white text-decoration-none">
                <i class="fas fa-box me-2"></i> Produk
            </a>
        </li>
        <li class="nav-item mb-4">
            <a href="?page=user" class="text-white text-decoration-none">
                <i class="fas fa-user me-2"></i> User
            </a>
        </li>
        <li class="nav-item mb-4">
    <?php if (isset($_SESSION['login'])): ?>
        <a href="modul/logout.php" class="text-white text-decoration-none" onclick="return confirm('Yakin ingin logout?')">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    <?php else: ?>
        <a href="modul/login.php" class="text-white text-decoration-none">
            <i class="fas fa-sign-in-alt me-2"></i> Login
        </a>
    <?php endif; ?>
</li>
    </ul>
</div>
</div>