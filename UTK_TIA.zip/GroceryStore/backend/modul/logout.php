<?php
session_start();
session_destroy();
header("Location: ../index.php"); // atau halaman awal kamu
exit();
