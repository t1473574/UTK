<div class="mt-4">
  <div class="card shadow-sm border-0">
    <div class="card-header text-white" style="background-color: #12606e;">
      <h5 class="mb-0"><i class="fas fa-folder-plus me-2"></i>Tambah Data Category</h5>
    </div>
    <div class="card-body">
      <form action="" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="title" class="form-label">Judul Kategori</label>
          <input type="text" name="ttl" id="title" class="form-control" placeholder="Masukkan nama kategori..." required>
        </div>

        <div class="mb-3">
          <label for="gambar" class="form-label">Gambar Kategori</label>
          <input type="file" name="gbr" id="gambar" class="form-control" accept="image/*" required>
        </div>

        <div class="d-flex justify-content-between">
                    <a href="?page=kate" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Kembali
                    </a>
                    <button type="submit" name="btn" class="btn text-white" style="background-color: #12606e;">
                        <i class="fas fa-upload me-1"></i> Upload
                    </button>
                </div>
      </form>

      <?php
      if(isset($_POST['btn'])){
          $path = '../gbrproject/';
          $ttl = $_POST['ttl'];
          $gbr = $_FILES['gbr']['name'];
          $tmp = $_FILES['gbr']['tmp_name'];

          if (move_uploaded_file($tmp, $path . $gbr)) {
              $sqlinput = $conn->prepare('INSERT INTO tb_kate(title, img_url) VALUES(:ttl, :img)');
              $sqlinput->bindParam(':ttl', $ttl);
              $sqlinput->bindParam(':img', $gbr);

              if ($sqlinput->execute()) {
                  echo '<div class="alert alert-success mt-3">✅ Data berhasil ditambahkan.</div>';
                  echo "<script>setTimeout(() => { window.location.href = '?page=kate'; }, 1500);</script>";
              } else {
                  echo '<div class="alert alert-danger mt-3">❌ Gagal menambahkan data: ' . $sqlinput->errorInfo()[2] . '</div>';
              }
          } else {
              echo '<div class="alert alert-danger mt-3">❌ Gagal upload gambar.</div>';
          }
      }
      ?>
    </div>
  </div>
</div>
