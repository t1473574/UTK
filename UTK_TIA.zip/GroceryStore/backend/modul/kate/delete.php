<?php
if (isset($_GET['idkat'])) {
    $id = $_GET['idkat'];

    // Gunakan statement prepared agar aman dari SQL Injection
    $b = $conn->prepare("DELETE FROM tb_kate WHERE idkate = :id");
    $b->bindParam(':id', $id, PDO::PARAM_INT);

    if ($b->execute()) {
        echo '
        <div class="alert alert-success mt-3" role="alert">
            <i class="fas fa-check-circle me-2"></i> Data kategori berhasil dihapus.
        </div>';
        echo "<script>setTimeout(() => { window.location.href = '?page=kate'; }, 1500);</script>";
    } else {
        echo '
        <div class="alert alert-danger mt-3" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i> Gagal menghapus data: ' . $b->errorInfo()[2] . '
        </div>';
    }
} else {
    echo '
    <div class="alert alert-warning mt-3" role="alert">
        <i class="fas fa-info-circle me-2"></i> ID kategori tidak ditemukan.
    </div>';
}
?>
