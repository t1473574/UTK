<?php
$id = $_GET['idkat'];
$b = $conn->prepare("SELECT * FROM tb_kate WHERE idkate = :id");
$b->bindParam(':id', $id);
$b->execute();
$result = $b->fetch(PDO::FETCH_ASSOC);
?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header text-white" style="background-color: #12606e;">
            <h5 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Category</h5>
        </div>
        <div class="card-body">
            <!-- Formulir untuk mengedit gambar -->
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $result['idkate'] ?>">

                <!-- Menampilkan title saat ini -->
                <div class="mb-3">
                    <input class="form-control" type="text" name="ttl" value="<?php echo $result['title']?>">
                </div>

                <!-- Menampilkan gambar saat ini -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Gambar Saat Ini:</label><br>
                    <img src="../gbrproject/<?= $result['img_url'] ?>" width="180" class="rounded shadow-sm mb-2" alt="Current Image">
                </div>

                <!-- Upload gambar baru -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Upload Gambar Baru (opsional):</label>
                    <input type="file" class="form-control" name="gbr">
                </div>

                <!-- Tombol navigasi dan submit -->
                <div class="d-flex justify-content-between">
                    <a href="?page=caro" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Kembali
                    </a>
                    <button name="btn" type="submit" class="btn text-white" style="background-color: #12606e;">
                        <i class="fas fa-save me-1"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
if (isset($_POST['btn'])) {
    $id = $_POST['id'];
    $ttl = $_POST['ttl'];
    $path = '../gbrproject/';

    // Cek apakah ada gambar baru yang di-upload
    if (!empty($_FILES['gbr']['name'])) {
        $gbr = $_FILES['gbr']['name'];
        move_uploaded_file($_FILES['gbr']['tmp_name'], $path . $gbr);
    } else {
        $gbr = $result['img_url'];  // Jika tidak ada gambar baru, gunakan gambar lama
    }

    // Query untuk mengupdate data
    $query = $conn->prepare("UPDATE tb_kate SET title = :ttl, img_url = :gbr WHERE idkate = :idc");
    $query->bindParam(':idc', $id);
    $query->bindParam(':ttl', $ttl);
    $query->bindParam(':gbr', $gbr);

    if ($query->execute()) {
        echo "<script>window.location.href='?page=kate';</script>";
        exit();
    } else {
        // Menampilkan pesan error jika update gagal
        echo "<div class='alert alert-danger mt-3'>❌ Gagal update data.</div>";
    }
}
?>
