<?php
require '../lib/koneksi.php'; 

// Ambil data user dari database
$stmt = $conn->query("SELECT * FROM tb_user");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="p-4" style="flex-grow: 1; background-color: #f8f9fa; min-height: 100vh;">
  <div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white border-0 pb-0">
      <h4 class="mb-4 mt-4 fw-semibold text-center" style="color:  #12606e;">
        <i class="fas fa-users me-2"></i>Daftar Pengguna
      </h4>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-hover text-center align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 35%;">Username</th>
              <th>Alamat</th>
            </tr>
          </thead>
          <tbody>
            <?php if (count($users) > 0): ?>
              <?php $no = 1; foreach ($users as $user): ?>
                <tr>
                  <td class="fw-bold"><?= $no++ ?></td>
                  <td><?= htmlspecialchars($user['username']) ?></td>
                  <td><?= htmlspecialchars($user['alamat']) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="3" class="text-muted">Belum ada data pengguna.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
