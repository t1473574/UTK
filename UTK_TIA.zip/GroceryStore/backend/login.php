<?php
require '../lib/koneksi.php';
session_start();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $identifier = $_POST['identifier']; // bisa username atau email
    $password   = $_POST['password'];

    // Ambil user berdasarkan username ATAU email
    $stmt = $conn->prepare("SELECT * FROM tb_admin WHERE email = :identifier OR username = :identifier");
    $stmt->execute(['identifier' => $identifier]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['userid'] = $user['userid'];
        $_SESSION['username'] = $user['username']; // Simpan username ke session
        $_SESSION['login'] = true;        
        header("Location: index.php?page=dashboard"); // arahkan ke dashboard admin
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Email/Username atau password salah!</div>";
    }

}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
        background: linear-gradient(to bottom right,rgb(4, 54, 62),rgb(114, 222, 232));
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        font-family: 'Segoe UI', sans-serif;
    }
    .login-card {
        background: #fff;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 0 15px rgba(0,0,0,0.15);
        width: 100%;
        max-width: 500px;
    }
    .form-control {
        background-color: #f0f0f0;
        border: none;
    }
    .btn-login {
        background-color: #007a8d;
        color: white;
        font-weight: bold;
        border-radius: 10px;
        padding: 8px 30px;
    }
    .btn-login:hover {
        background-color:rgb(81, 199, 232);
    }
  </style>
</head>
<body>

<div class="login-card text-center">
  <h4 class="mb-4">Login</h4>

  <?php if (isset($message)) echo $message; ?>

  <form method="POST">
    <div class="mb-3 text-start">
      <label for="identifier" class="form-label">Username atau Email:</label>
      <input type="text" name="identifier" class="form-control" placeholder="Masukkan username atau email" required>
    </div>

    <div class="mb-3 text-start">
      <label for="password" class="form-label">Password:</label>
      <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
    </div>

    <button type="submit" class="btn btn-login w-100 mt-2">Login</button>
  </form>

  <p class="text-center mt-3">
    Belum punya akun? <a href="regis.php">Daftar di sini</a>
  </p>
</div>

</body>
</html>
