<?php
require '../lib/koneksi.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email    = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Cek apakah email sudah terdaftar
    $cek = $conn->prepare("SELECT * FROM tb_admin WHERE email = :email");
    $cek->execute(['email' => $email]);
    if ($cek->rowCount() > 0) {
        $message = "<div class='alert alert-danger'>Email sudah terdaftar!</div>";
    } else {
        // Simpan data baru
        $stmt = $conn->prepare("INSERT INTO tb_admin (username, email, password) VALUES (:username, :email, :password)");
        $stmt->execute([
            'username' => $username,
            'email' => $email,
            'password' => $password
        ]);
        $message = "<div class='alert alert-success'>Registrasi berhasil! Silakan <a href='login.php'>login</a>.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Register</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
        background: linear-gradient(to bottom right,rgb(4, 54, 62),rgb(114, 222, 232));
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        font-family: 'Segoe UI', sans-serif;
    }
    .login-card {
        background: #fff;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 0 15px rgba(0,0,0,0.15);
        width: 100%;
        max-width: 500px;
    }
    .form-control {
        background-color: #f0f0f0;
        border: none;
    }
    .btn-login {
        background-color: #007a8d;
        color: white;
        font-weight: bold;
        border-radius: 10px;
        padding: 8px 30px;
    }
    .btn-login:hover {
        background-color:rgb(81, 199, 232);
    }
  </style>
</head>
<body>

<div class="login-card text-center">
  <h4 class="mb-4">Register</h4>

  <?php if (isset($message)) echo $message; ?>

  <form method="POST">
    <div class="mb-3 text-start">
      <label for="username" class="form-label">Username:</label>
      <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
    </div>

    <div class="mb-3 text-start">
      <label for="email" class="form-label">Email:</label>
      <input type="email" name="email" class="form-control" placeholder="Masukkan email" required>
    </div>

    <div class="mb-3 text-start">
      <label for="password" class="form-label">Password:</label>
      <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
    </div>

    <button type="submit" class="btn btn-login w-100 mt-2">Daftar</button>
  </form>

  <p class="text-center mt-3">
    Sudah punya akun? <a href="login.php">Login di sini</a>
  </p>
</div>

</body>
</html>
