<?php 
session_start();
require "../lib/koneksi.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="aset/aset.css">
</head>
<body>
<div class="d-flex">
<?php
  include "modul/sidebar.php";
?>

<div class="main-content" style="flex: 1; padding: 20px;">
<?php 
    $page = $_GET['page'] ?? 'dashboard';

    switch ($page) {
        case 'dashboard':
            include "modul/das.php";
            break;
        case 'caro':
            include "modul/caro/data.php";
            break;
        case 'addcaro':
            include "modul/caro/add.php";
            break;
        case 'deletecaro':
            include "modul/caro/delete.php";
            break;
        case 'editcaro':
            include "modul/caro/edit.php";
            break;
        case 'kate':
            include "modul/kate/data.php";
            break;
        case 'addkate':
            include "modul/kate/add.php";
            break;
        case 'deletekate':
            include "modul/kate/delete.php";
            break;
        case 'editkate':
            include "modul/kate/edit.php";
            break;
        case 'produk':
            include "modul/produk/data.php";
            break;
        case 'addproduk':
            include "modul/produk/add.php";
            break;
         case 'deletepro':
            include "modul/produk/delete.php";
            break;
        case 'editpro':
            include "modul/produk/edit.php";
            break;
        case 'user':
            include "modul/user.php";
            break;
        default:
            echo "<h4>Halaman tidak ditemukan.</h4>";
            break;    
    }
?>
</div>

 

 

  <!-- Footer -->
<!-- <?php 
include "../modul/footer"
?> -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
