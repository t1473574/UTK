<?php
session_start(); // ⬅️ hanya satu kali
require 'lib/koneksi.php';

if (isset($_SESSION['username'])) {
  header('Location: profil.php');
  exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM tb_user WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['userid'] = $user['userid'];
        header("Location: index.php");
        exit();
    } else {
        $message = "<div class='alert alert-danger text-center mt-3'>Username atau password salah!</div>";
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f1f8f7;
      font-family: 'Segoe UI', sans-serif;
    }
    .login-container {
      display: flex;
      height: 100vh;
      justify-content: center;
      align-items: center;
      background-color: #f1f8f7;
    }
    .login-card {
      background: #ffffff;
      border-radius: 20px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
      display: flex;
      overflow: hidden;
      max-width: 900px;
      width: 100%;
    }
    .login-form {
      padding: 50px 40px;
      flex: 1;
    }
    .login-form h3 {
      margin-bottom: 30px;
      color: #0a6156;
    }
    .form-control {
      border-radius: 30px;
      background-color: #f4f9f8;
      border: none;
      padding-left: 20px;
    }
    .form-label {
      font-weight: 500;
      color: #555;
    }
    .login-form button {
      border-radius: 30px;
      padding: 10px 0;
      font-weight: bold;
      background-color: #3bbca7;
      border: none;
    }
    .login-form button:hover {
      background-color: #2da38f;
    }
    .login-image {
      background: linear-gradient(to bottom right,rgb(11, 83, 69), #a9f3e1);
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .login-image img {
      width: 70%;
    }
    .top-buttons {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
  gap: 10px;
}

.top-buttons .btn {
  border-radius: 30px;
  padding: 8px 25px;
  font-weight: bold;
  text-decoration: none;
  transition: 0.3s;
}

.top-buttons .active {
  background-color: #1ca89e;
  color: white;
  border: none;
}

.top-buttons .inactive {
  background-color: transparent;
  border: 1px solid #1ca89e;
  color: #1ca89e;
}

.top-buttons .inactive:hover {
  background-color: #1ca89e;
  color: white;
}

  </style>
</head>
<body>

<div class="login-container">
  <div class="login-card">
    <div class="login-form">
         <h3 class="text-center">Login</h3>
      
    <div class="top-buttons">
  <a href="login.php" class="btn <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'active' : 'inactive'; ?>">Login</a>
  <a href="regis.php" class="btn <?php echo basename($_SERVER['PHP_SELF']) == 'regis.php' ? 'active' : 'inactive'; ?>">Sign Up</a>
</div>


      <h3>Login</h3>

      <?php if (isset($message)) echo $message; ?>

      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Email / Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>

        <div class="d-grid">
          <button type="submit" class="btn text-white">Login</button>
        </div>
      </form>
    </div>
    <div class="login-image">
      <img src="aset/image/ilus.png" alt="Ilustrasi Login">
    </div>
  </div>
</div>

</body>
</html>
