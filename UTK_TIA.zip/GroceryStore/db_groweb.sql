-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 16 Bulan Mei 2025 pada 01.14
-- Versi server: 8.0.17
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_groweb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `idadmin` int(6) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`idadmin`, `email`, `password`, `username`) VALUES
(1, 'wp_emily.my@pro', '$2y$10$53D7DQVaQ8T5HLsd9j10QO9oww1KNLaUHrqQEZKccWPEPm2QijjH6', '0'),
(2, 'tia@email.com', '$2y$10$rKxlMtgSRZQHAJj.3B9VjuexUgE2Udr7nlS68LCYq.rJf9YPwApT6', '0'),
(3, 'yuyu@com', '$2y$10$wKi/BIw.RtvtFxkQKZKtn.KQDQQAw8138LZo0AZXjvVsGblg2JW5S', 'yuyu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_caro`
--

CREATE TABLE `tb_caro` (
  `idcaro` int(255) NOT NULL,
  `img_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_caro`
--

INSERT INTO `tb_caro` (`idcaro`, `img_url`) VALUES
(1, 'Banner Toko Sembako Korporat Biru dan Putih.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_cart`
--

CREATE TABLE `tb_cart` (
  `idcart` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `idproduk` int(11) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_cart`
--

INSERT INTO `tb_cart` (`idcart`, `userid`, `idproduk`, `jumlah`, `created_at`) VALUES
(43, 12, 4, '1', '2025-05-12 11:21:45'),
(44, 12, 5, '1', '2025-05-12 11:22:06'),
(45, 12, 13, '1', '2025-05-12 11:22:29'),
(46, 12, 11, '1', '2025-05-12 11:23:26'),
(77, 16, 10, '1', '2025-05-14 12:42:54'),
(78, 16, 4, '1', '2025-05-14 12:43:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kate`
--

CREATE TABLE `tb_kate` (
  `idkate` int(6) NOT NULL,
  `title` varchar(255) NOT NULL,
  `img_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_kate`
--

INSERT INTO `tb_kate` (`idkate`, `title`, `img_url`) VALUES
(13, 'Fruits', 'buah-removebg-preview.png'),
(15, 'Spice', 'dapur-removebg-preview (1).png'),
(16, 'Vegetables', '222913150daf27a3f7a56df0cfb049d1-removebg-preview.png'),
(17, 'Medecine', 'obat-removebg-preview.png'),
(18, 'Meats', 'meat-removebg-preview.png'),
(19, 'Baby care', '437d9e2e69129b552297e20356023cf2-removebg-preview.png'),
(20, 'For bath', '291821ec43e1423d0e4f43703135f6a8-removebg-preview.png'),
(21, 'Stationery', 'atk-removebg-preview.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_order`
--

CREATE TABLE `tb_order` (
  `idorder` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_order`
--

INSERT INTO `tb_order` (`idorder`, `userid`, `tanggal`, `total`) VALUES
(1, 10, '2025-05-06 15:48:57', 15000),
(2, 10, '2025-05-06 15:49:49', 0),
(3, 10, '2025-05-06 15:50:24', 25000),
(4, 10, '2025-05-06 15:51:59', 30000),
(5, 10, '2025-05-06 15:54:10', 15000),
(6, 10, '2025-05-06 15:55:38', 15000),
(7, 10, '2025-05-06 15:57:16', 25000),
(8, 10, '2025-05-06 16:01:44', 15000),
(9, 10, '2025-05-06 16:05:50', 15000),
(10, 10, '2025-05-06 16:09:15', 25000),
(11, 10, '2025-05-06 16:13:24', 0),
(12, 10, '2025-05-06 16:15:00', 0),
(13, 10, '2025-05-06 16:17:54', 0),
(14, 10, '2025-05-06 16:17:55', 0),
(15, 10, '2025-05-06 16:22:44', 15000),
(16, 10, '2025-05-06 16:26:44', 25000),
(17, 10, '2025-05-06 16:38:24', 15000),
(18, 10, '2025-05-06 16:40:14', 15000),
(19, 10, '2025-05-06 16:45:48', 15000),
(20, 10, '2025-05-06 16:48:45', 0),
(21, 10, '2025-05-06 16:51:08', 15000),
(22, 10, '2025-05-06 16:55:28', 0),
(23, 10, '2025-05-06 16:57:34', 15000),
(24, 10, '2025-05-06 17:05:04', 0),
(25, 10, '2025-05-06 17:05:32', 15000),
(26, 10, '2025-05-06 17:09:07', 15000),
(27, 10, '2025-05-07 07:48:28', 25000),
(28, 10, '2025-05-07 07:48:51', 5000),
(29, 10, '2025-05-07 08:10:47', 25000),
(30, 10, '2025-05-07 08:27:43', 57000),
(31, 10, '2025-05-07 08:30:56', 0),
(32, 10, '2025-05-07 08:31:47', 15000),
(33, 10, '2025-05-07 10:07:58', 55000),
(34, 10, '2025-05-07 11:06:34', 25000),
(35, 12, '2025-05-07 13:01:51', 21000),
(36, 12, '2025-05-07 13:02:11', 74000),
(37, 10, '2025-05-07 13:56:51', 3000000),
(38, 10, '2025-05-08 11:05:26', 60000),
(39, 10, '2025-05-08 11:05:41', 25000),
(40, 10, '2025-05-08 11:40:04', 15000),
(41, 12, '2025-05-08 13:48:52', 40000),
(42, 14, '2025-05-08 13:53:06', 15000),
(43, 14, '2025-05-08 13:55:47', 128000),
(44, 10, '2025-05-14 08:29:41', 30000),
(45, 10, '2025-05-14 10:15:15', 15000),
(46, 10, '2025-05-14 12:52:31', 17000),
(47, 10, '2025-05-14 16:52:18', 96000),
(48, 10, '2025-05-14 16:55:59', 39000),
(49, 10, '2025-05-14 16:59:08', 28000),
(50, 10, '2025-05-14 17:00:41', 21000),
(51, 10, '2025-05-14 17:00:55', 15000),
(52, 10, '2025-05-14 17:02:01', 15000),
(53, 10, '2025-05-14 17:03:07', 15000),
(54, 10, '2025-05-14 17:06:51', 15000),
(55, 10, '2025-05-14 17:07:40', 15000),
(56, 10, '2025-05-14 17:10:43', 19000),
(57, 16, '2025-05-14 19:42:27', 15000),
(58, 16, '2025-05-14 19:42:45', 30000),
(59, 10, '2025-05-15 11:49:31', 15000),
(60, 10, '2025-05-15 11:50:02', 40000),
(61, 14, '2025-05-15 13:58:24', 25000),
(62, 14, '2025-05-15 13:59:37', 67000),
(63, 14, '2025-05-15 15:22:25', 15000),
(64, 10, '2025-05-15 15:30:26', 15000),
(65, 10, '2025-05-15 15:31:04', 41000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_order_detail`
--

CREATE TABLE `tb_order_detail` (
  `iddetail` int(11) NOT NULL,
  `idorder` int(11) NOT NULL,
  `idproduk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_order_detail`
--

INSERT INTO `tb_order_detail` (`iddetail`, `idorder`, `idproduk`, `jumlah`, `harga`) VALUES
(1, 1, 18, 1, '15000'),
(2, 3, 5, 1, '25000'),
(3, 4, 4, 1, '15000'),
(4, 4, 7, 1, '15000'),
(5, 5, 4, 1, '15000'),
(6, 6, 4, 1, '15000'),
(7, 7, 5, 1, '25000'),
(8, 8, 4, 1, '15000'),
(9, 9, 4, 1, '15000'),
(10, 10, 5, 1, '25000'),
(11, 15, 4, 1, '15000'),
(12, 16, 5, 1, '25000'),
(13, 17, 4, 1, '15000'),
(14, 18, 4, 1, '15000'),
(15, 19, 4, 1, '15000'),
(16, 21, 4, 1, '15000'),
(17, 23, 4, 1, '15000'),
(18, 25, 4, 1, '15000'),
(19, 26, 4, 1, '15000'),
(20, 27, 5, 1, '25000'),
(21, 28, 2, 1, '5000'),
(22, 29, 5, 1, '25000'),
(23, 30, 4, 2, '15000'),
(24, 30, 5, 1, '25000'),
(25, 30, 3, 1, '2000'),
(26, 32, 4, 1, '15000'),
(27, 33, 5, 1, '25000'),
(28, 33, 7, 1, '15000'),
(29, 33, 18, 1, '15000'),
(30, 34, 5, 1, '25000'),
(31, 35, 11, 1, '21000'),
(32, 36, 5, 2, '25000'),
(33, 36, 2, 1, '5000'),
(34, 36, 3, 2, '2000'),
(35, 36, 4, 1, '15000'),
(36, 37, 6, 100, '30000'),
(37, 38, 5, 1, '25000'),
(38, 38, 4, 1, '15000'),
(39, 38, 12, 1, '3000'),
(40, 38, 3, 1, '2000'),
(41, 38, 7, 1, '15000'),
(42, 39, 5, 1, '25000'),
(43, 40, 4, 1, '15000'),
(44, 41, 5, 1, '25000'),
(45, 41, 4, 1, '15000'),
(46, 42, 18, 1, '15000'),
(47, 43, 5, 1, '25000'),
(48, 43, 2, 1, '5000'),
(49, 43, 3, 1, '2000'),
(50, 43, 10, 1, '17000'),
(51, 43, 6, 1, '30000'),
(52, 43, 18, 1, '15000'),
(53, 43, 16, 1, '27000'),
(54, 43, 17, 1, '4000'),
(55, 43, 8, 1, '2000'),
(56, 43, 9, 1, '1000'),
(57, 44, 4, 2, '15000'),
(58, 45, 4, 1, '15000'),
(59, 46, 14, 1, '17000'),
(60, 47, 5, 3, '25000'),
(61, 47, 12, 1, '3000'),
(62, 47, 18, 1, '15000'),
(63, 47, 13, 1, '3000'),
(64, 48, 10, 1, '17000'),
(65, 48, 11, 1, '21000'),
(66, 48, 9, 1, '1000'),
(67, 49, 5, 1, '25000'),
(68, 49, 13, 1, '3000'),
(69, 50, 4, 1, '15000'),
(70, 50, 13, 1, '3000'),
(71, 50, 12, 1, '3000'),
(72, 51, 4, 1, '15000'),
(73, 52, 4, 1, '15000'),
(74, 53, 4, 1, '15000'),
(75, 54, 4, 1, '15000'),
(76, 55, 4, 1, '15000'),
(77, 56, 9, 1, '1000'),
(78, 56, 4, 1, '15000'),
(79, 56, 12, 1, '3000'),
(80, 57, 4, 1, '15000'),
(81, 58, 4, 1, '15000'),
(82, 58, 7, 1, '15000'),
(83, 59, 4, 1, '15000'),
(84, 60, 5, 1, '25000'),
(85, 60, 4, 1, '15000'),
(86, 61, 5, 1, '25000'),
(87, 62, 4, 1, '15000'),
(88, 62, 2, 1, '5000'),
(89, 62, 3, 1, '2000'),
(90, 62, 6, 1, '30000'),
(91, 62, 18, 1, '15000'),
(92, 63, 4, 1, '15000'),
(93, 64, 4, 1, '15000'),
(94, 65, 2, 1, '5000'),
(95, 65, 10, 1, '17000'),
(96, 65, 14, 1, '17000'),
(97, 65, 8, 1, '2000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_produk`
--

CREATE TABLE `tb_produk` (
  `idproduk` int(6) NOT NULL,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `harga` varchar(255) NOT NULL,
  `idkate` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_produk`
--

INSERT INTO `tb_produk` (`idproduk`, `nama`, `img`, `harga`, `idkate`) VALUES
(2, 'sayur bayem', '78bbfcc28e81444c3e47ce1f1f6d3cf1-removebg-preview.png', '5000', 16),
(3, 'wortel', 'dfc8a4891c9bea0b9224ab22c5c3c8ab-removebg-preview.png', '2000', 16),
(4, 'apel', 'd023a80bb6ca00bcad651d0fc29e5e56-removebg-preview.png', '15000', 13),
(5, 'anggur', 'c76f655eb1b960f72797b02e7be9ca8f-removebg-preview.png', '25000', 13),
(6, 'daging ayam', '821dc55cf77afa20b574be5f042a3d00-removebg-preview.png', '30000', 18),
(7, 'udang', '2eae6df1ed5b3d62359ae07058d6f478-removebg-preview.png', '15000', 18),
(8, 'pulpen', 'f19f1072109e8ae4c19b71539e206d27-removebg-preview.png', '2000', 21),
(9, 'pensil', 'c8adfa29ca4fa7f7e5f48014307ec144-removebg-preview.png', '1000', 21),
(10, 'panadol', '0b096d541393541f267483023c1ee325-removebg-preview.png', '17000', 17),
(11, 'woods', 'c390890db7bc5b61134c5df88ebaf4ae-removebg-preview.png', '21000', 17),
(12, 'jahe', '557848d9bfdc55a003853a7d1921c2a1-removebg-preview.png', '3000', 15),
(13, 'kunyit', '0915e05648955ae049b54e73ed40d286-removebg-preview.png', '3000', 15),
(14, 'minyak telon', '76f75f666ff522d23075c15d2eaf6928-removebg-preview.png', '17000', 19),
(15, 'bedak bayi', '5c46490fd889f53a43c0c2f77f7ce431-removebg-preview.png', '18000', 19),
(16, 'sampo', '6c3f5275f3a85cdb2a41d5b2ffd6782f-removebg-preview.png', '27000', 20),
(17, 'sabun', 'cdd260053793d13ba95ce7196ab63df5-removebg-preview.png', '4000', 20),
(18, 'bakso', 'fa7b879d-0d8e-4dd8-a430-bbe610f79eda-removebg-preview.png', '15000', 18);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `userid` int(6) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `img_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`userid`, `username`, `password`, `alamat`, `fullname`, `no_hp`, `img_url`) VALUES
(7, 'Tia', '$2y$10$pfL3IyNJIpUxzU6/exO6OeId82Ft5mxQQ7oaKX6djlmUmCqdxauFC', '', '', '', ''),
(8, 'kia', '$2y$10$FRrhMPYoejGtH5Twn461.ueRbxcVqXZKiCGve1PI0P6Qdr4NOWa56', '', '', '', ''),
(9, 'yu', '$2y$10$oF.InLe4CYWTq6ZtlUNdmuBCg48xbYYjUk4tSCbuBwgH58lI7DfcO', '', '', '', ''),
(10, 'yi', '$2y$10$OT6RKat2fiOI7O3aLiD8v.St/.kL/bNN99WU307QRdLi1aFukSnP6', 'lorem ipsum', 'yiyiyi', '2345678', '681ad5139cc9b.jpg'),
(11, 'yiyi@com', '$2y$10$CuOl3IOaHVxRdXYcwmuULe7XTWmEDID3L4O9FHRkPnqXwQ7bFswl2', 'jln.gm kenangan', 'yuyu yiyi', '0987653432', '68163ed0d1e00.jpg'),
(12, 'ria', '$2y$10$0B.ZeZR4/CrC256CvektPuq5tQCU9isVrS.IqBEyEISstrsWugkKe', 'jl.al-mansyur lorem ipsum sit dolor amet', 'ria rian', '0876594329', '681647494f9df.jpg'),
(13, 'wp_emily.my@proystore.in', '$2y$10$ZD.U5VT.zNK7OAComGfQheKQ3ptuyd8QIO3HgflWk6vQCAoeRXfyq', 'jln.gm kenangan', '', '', ''),
(14, 'nica', '$2y$10$.IypT4MC95npRVct0ixnq.syxfHll5Wt3F6SI4UuV9XpU3P0r7cMa', 'cimpaeun', '', '', ''),
(15, 'tia aja', '$2y$10$dpzV9jopHVBOuVq4.FGCnOGHKT2jwJn1UsNUsfXRiZXILz3tTWaPq', 'jln.lorem ipsum sit dolor amet', '', '', ''),
(16, 'tia@email.com', '$2y$10$YLmfiNAjlorRijDSyy7Kq.Ml1LuQvEpwqPQfhTxDSsORBlu2DRoEi', 'lorem ipsum', 'TIA LESTARI', '2345678', '68248ef580b95.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`idadmin`);

--
-- Indeks untuk tabel `tb_caro`
--
ALTER TABLE `tb_caro`
  ADD PRIMARY KEY (`idcaro`);

--
-- Indeks untuk tabel `tb_cart`
--
ALTER TABLE `tb_cart`
  ADD PRIMARY KEY (`idcart`);

--
-- Indeks untuk tabel `tb_kate`
--
ALTER TABLE `tb_kate`
  ADD PRIMARY KEY (`idkate`);

--
-- Indeks untuk tabel `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`idorder`);

--
-- Indeks untuk tabel `tb_order_detail`
--
ALTER TABLE `tb_order_detail`
  ADD PRIMARY KEY (`iddetail`);

--
-- Indeks untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`idproduk`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `idadmin` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_caro`
--
ALTER TABLE `tb_caro`
  MODIFY `idcaro` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_cart`
--
ALTER TABLE `tb_cart`
  MODIFY `idcart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT untuk tabel `tb_kate`
--
ALTER TABLE `tb_kate`
  MODIFY `idkate` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `tb_order`
--
ALTER TABLE `tb_order`
  MODIFY `idorder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT untuk tabel `tb_order_detail`
--
ALTER TABLE `tb_order_detail`
  MODIFY `iddetail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  MODIFY `idproduk` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `userid` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
