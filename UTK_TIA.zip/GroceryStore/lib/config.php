<?php
define('BASE_URL', '/GROCERYSTORE/'); // Ganti ini sesuai nama folder project kamu di htdocs
