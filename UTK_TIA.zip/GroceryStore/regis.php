<?php
session_start();
require 'lib/koneksi.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $alamat   = $_POST['alamat'];

    $cek = $conn->prepare("SELECT * FROM tb_user WHERE username = :username");
    $cek->execute(['username' => $username]);

    if ($cek->rowCount() > 0) {
        $message = "<div class='alert alert-warning text-center mt-3'>Username sudah digunakan!</div>";
    } else {
        $insert = $conn->prepare("INSERT INTO tb_user (username, password, alamat) VALUES (:username, :password, :alamat)");
        $insert->execute(['username' => $username, 'password' => $password, 'alamat' => $alamat]);

        $message = "<div class='alert alert-success text-center mt-3'>Registrasi berhasil! <a href='login.php'>Login sekarang</a>.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Registrasi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #eafaf8;
      font-family: 'Segoe UI', sans-serif;
    }

    .container-box {
      max-width: 900px;
      margin: auto;
      margin-top: 120px;
      background-color: white;
      border-radius: 20px;
      box-shadow: 0 0 30px rgba(0, 0, 0, 0.08);
      overflow: hidden;
      display: flex;
    }

    .form-section {
      padding: 40px;
      flex: 1;
    }

    .form-section h3 {
      color: #1ca89e;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .form-control {
      border-radius: 30px;
      background-color: #f3fbf9;
      padding-left: 20px;
      border: 1px solid #cfeae6;
    }

    .btn-custom {
      background-color: #1ca89e;
      border: none;
      border-radius: 30px;
      padding: 10px;
      font-weight: bold;
      transition: 0.3s ease;
    }

    .btn-custom:hover {
      background-color: #178a82;
    }

    .top-buttons {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-bottom: 30px;
    }

    .top-buttons a {
      border-radius: 30px;
      padding: 8px 25px;
      font-weight: bold;
    }

    .top-buttons .active {
      background-color: #1ca89e;
      color: white;
    }

    .top-buttons .inactive {
      border: 1px solid #1ca89e;
      color: #1ca89e;
      background-color: transparent;
    }

    .image-section {
      background: linear-gradient(to bottom right, #78ded2, rgb(7, 93, 83));
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .image-section img {
      width: 80%;
    }

    @media (max-width: 768px) {
      .container-box {
        flex-direction: column;
      }

      .image-section {
        display: none;
      }
    }
  </style>
</head>
<body>

<div class="container-box">
  <div class="form-section">
    <h3 class="text-center">Daftar Akun Baru</h3>

    <div class="top-buttons">
      <a href="login.php" class="btn inactive">Login</a>
      <a href="regis.php" class="btn active">Sign Up</a>
    </div>

    <?php if (isset($message)) echo $message; ?>

    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Email / Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <div class="mb-4">
        <label class="form-label">Alamat</label>
        <input type="text" name="alamat" class="form-control" required>
      </div>

      <div class="d-grid">
        <button type="submit" class="btn btn-custom text-white">Register</button>
      </div>
    </form>
  </div>

  <div class="image-section">
    <img src="aset/image/ilus.png" alt="Illustration">
  </div>
</div>

</body>
</html>
