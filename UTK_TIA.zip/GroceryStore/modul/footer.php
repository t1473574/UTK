<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- About Us Section with Gradient Background -->
<section class="py-5 mt-4" style="background: linear-gradient(135deg, #12606e 0%, #e8f1f2 100%);">
  <div class="container">
    <div class="row align-items-center">
      <!-- Text Column -->
      <div class="col-lg-6 mb-4 mb-lg-0 text-white">
        <h2 class="mb-4" style="font-weight: 700;">ABOUT <span style="color: #ffffffcc;">US</span></h2>
        <p style="font-size: 1.1rem; line-height: 1.8;">
          Grocery stores are retail establishments that sell food and other household items. 
          They typically offer a wide variety of products, including fresh produce, meats, dairy, 
          and packaged goods, catering to the daily needs of consumers.
        </p>
      </div>

      <!-- Image Column -->
      <div class="col-lg-6 text-center">
        <img src="aset/image/ilu.png" alt="Grocery Store" class="img-fluid rounded shadow" style="max-height: 350px; object-fit: cover; border: 4px solid #ffffffcc;">
      </div>
    </div>
  </div>
</section>

<footer style="background: linear-gradient(135deg,rgb(5, 60, 67),rgb(149, 233, 229));" class="text-white pt-4 pb-3 mt-5 shadow-lg">
    <div class="container">
        <div class="row text-center text-md-start align-items-center">
            <div class="col-md-4 mb-3 mb-md-0">
                <h5 class="fw-bold">Grocery Store</h5>
                <p class="mb-1">Belanja mudah, cepat, dan hemat setiap hari.</p>
                <div class="mt-2">
                    <a href="#" class="text-white me-3 fs-5"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-white me-3 fs-5"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-white me-3 fs-5"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-white fs-5"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            <div class="col-md-4 mb-3 mb-md-0">
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white text-decoration-none d-block py-1 hover-opacity">Beranda</a></li>
                    <li><a href="#" class="text-white text-decoration-none d-block py-1 hover-opacity">Produk</a></li>
                    <li><a href="#" class="text-white text-decoration-none d-block py-1 hover-opacity">Tentang Kami</a></li>
                    <li><a href="#" class="text-white text-decoration-none d-block py-1 hover-opacity">Kontak</a></li>
                </ul>
            </div>
            <div class="col-md-4 text-md-end">
                <h6 class="fw-bold">Kontak Kami</h6>
                <p class="mb-0 small">Jl. Belanja No.123, Kota Belanja</p>
                <p class="mb-0 small">Email: info@grocerystore.com</p>
                <p class="mb-0 small">Telepon: 0812-3456-7890</p>
            </div>
        </div>
        <hr class="border-white mt-4 mb-2">
        <div class="text-center small">&copy; 2025 Grocery Store. All rights reserved.</div>
    </div>
</footer>

<style>
    .hover-opacity:hover {
        opacity: 0.8;
        transition: 0.3s;
    }
</style>
