<?php
$sql = "SELECT img_url FROM tb_caro";
$stmt = $conn->prepare($sql);
$stmt->execute();

$carouselItems = '';
$isFirstItem = true;

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $activeClass = $isFirstItem ? 'active' : '';
    $imgUrl = htmlspecialchars($row['img_url']);

    $carouselItems .= <<<HTML
    <div class="carousel-item $activeClass">
        <img src="gbrproject/$imgUrl" class="d-block w-100 img-fluid" alt="Slider Image" >
    </div>
    HTML;

    $isFirstItem = false;
}
$conn = null;
?>
<?php
$isLoggedIn = isset($_SESSION['username']);
?>

<style>
  .login-banner {
    border-left: 6px solid #12606e;
    border-radius: 10px;
    background:rgb(255, 255, 255);
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease-in-out;
    box-shadow: 8px 8px 24px rgba(18, 96, 110, 0.25);
  }

  .login-banner:hover {
    transform: translateY(-2px);
  }

  .login-banner h6 {
    font-weight: 700;
    color: #12606e;
    font-size: 1.2rem;
    margin-bottom: 4px;
  }

  .login-banner p {
    margin: 0;
    font-weight: 500;
    color: #555;
    font-size: 0.95rem;
  }

  .login-btn {
    background-color: #12606e;
    color: white;
    font-weight: 600;
    border: none;
    padding: 10px 18px;
    border-radius: 8px;
    transition: background-color 0.3s ease;
  }

  .login-btn:hover {
    background-color: #0d4d59;
  }

  @media (max-width: 576px) {
    .login-banner {
      flex-direction: column;
      text-align: center;
      gap: 15px;
    }
  }
</style>

<body class="p-3">
  <div class="login-banner">
    <div>
      <?php if (!$isLoggedIn): ?>
        <h6>Hey, sign in first!</h6>
        <p>Set your address and start shopping!</p>
      <?php else: ?>
        <h6>Welcome back!</h6>
        <p>Ready to shop? Let's go!</p>
      <?php endif; ?>
    </div>
    
    <?php if (!$isLoggedIn): ?>
      <a href="regis.php">
        <button class="btn login-btn">Sign in</button>
      </a>
    <?php else: ?>
      <a href="<?= BASE_URL ?>index2.php">
        <button class="btn login-btn">Shop Now</button>
      </a>
    <?php endif; ?>
  </div>
</body>

<div id="Carousel" class="carousel slide mb-3 mt-3" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php echo $carouselItems; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#Carousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#Carousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<body class="p-3">
