<?php
include_once __DIR__ . '/../lib/config.php';
// Jika ingin tampilkan navbar di atas
?>

<div class="container mt-5 mb-5">
  <!-- Judul Halaman -->
  <h3 class="text-center mb-4" style="font-family: 'Segoe UI', sans-serif; color: #12606e;">Contact Us</h3>

  <div class="row">
    <!-- Informasi Kontak -->
    <div class="col-md-6 mb-4">
      <div class="card shadow-lg p-4" style="border-radius: 15px; background-color: #f8f9fa;">
        <h5 class="mb-3" style="color: #12606e;">Our Office</h5>
        <p><i class="fas fa-map-marker-alt" style="color: #00cc00;"></i> Jl. Contoh Alamat No. 123, Jakarta</p>
        <p><i class="fas fa-phone" style="color: #00cc00;"></i> +62 812 3456 7890</p>
        <p><i class="fas fa-envelope" style="color: #00cc00;"></i> info@grocerystore.com</p>
      </div>
    </div>

    <!-- Form Kontak -->
    <div class="col-md-6">
      <div class="card shadow-lg p-4" style="border-radius: 15px; background-color: #f8f9fa;">
        <h5 class="mb-3" style="color: #12606e;">Send Us a Message</h5>
        <form action="#" method="POST">
          <div class="mb-3">
            <label for="name" class="form-label">Your Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
          </div>

          <div class="mb-3">
            <label for="email" class="form-label">Your Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>

          <div class="mb-3">
            <label for="message" class="form-label">Your Message</label>
            <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
          </div>

          <button type="submit" class="btn btn-success w-100" style="font-weight: bold; border-radius: 25px; transition: transform 0.2s;">
            Send Message
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Bagian Review -->
  <div class="row mt-5">
    <h4 class="text-center mb-4" style="font-family: 'Segoe UI', sans-serif; color: #12606e;">Customer Reviews</h4>

    <div class="col-12">
      <div id="reviewCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <!-- Review 1 -->
          <div class="carousel-item active">
            <div class="card text-center shadow-lg p-4" style="border-radius: 15px; background-color: #f4f6f9;">
              <div class="card-body">
                <h5 class="card-title">John Doe</h5>
                <p class="card-text">"I had an amazing experience! The customer service was excellent and the product quality exceeded my expectations. Highly recommend!"</p>
              </div>
            </div>
          </div>
          <!-- Review 2 -->
          <div class="carousel-item">
            <div class="card text-center shadow-lg p-4" style="border-radius: 15px; background-color: #f4f6f9;">
              <div class="card-body">
                <h5 class="card-title">Jane Smith</h5>
                <p class="card-text">"Fast delivery and fantastic products. I will definitely be coming back for more!"</p>
              </div>
            </div>
          </div>
          <!-- Review 3 -->
          <div class="carousel-item">
            <div class="card text-center shadow-lg p-4" style="border-radius: 15px; background-color: #f4f6f9;">
              <div class="card-body">
                <h5 class="card-title">Michael Johnson</h5>
                <p class="card-text">"Great experience! Easy to use website, fast shipping, and high-quality products. Five stars!"</p>
              </div>
            </div>
          </div>
        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#reviewCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#reviewCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
  // Animasi tombol kirim pesan
  document.querySelector('.btn-success').addEventListener('mouseover', function () {
    this.style.transform = 'scale(1.05)';
  });
  document.querySelector('.btn-success').addEventListener('mouseout', function () {
    this.style.transform = 'scale(1)';
  });
</script>
