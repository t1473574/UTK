<?php
session_start();
include_once __DIR__ . '/../lib/config.php';
include "../lib/koneksi.php";

if (!isset($_SESSION['userid'])) {
    header("location: ../login.php");
}

// Fungsi untuk menambahkan produk ke keranjang
if (isset($_GET['add_to_cart'])) {
    $idProduk = $_GET['add_to_cart'];

    // Cek apakah produk sudah ada di keranjang
    $stmtCek = $conn->prepare("SELECT * FROM tb_cart WHERE userid = :userid AND idproduk = :idproduk");
    $stmtCek->execute([
        ':userid' => $userid,
        ':idproduk' => $idProduk
    ]);

    if ($stmtCek->rowCount() > 0) {
        // Jika sudah ada, update jumlah +1
        $conn->prepare("UPDATE tb_cart SET jumlah = jumlah + 1 WHERE userid = :userid AND idproduk = :idproduk")
            ->execute([
                ':userid' => $userid,
                ':idproduk' => $idProduk
            ]);
    } else {
        // Jika belum ada, insert baru
        $conn->prepare("INSERT INTO tb_cart (userid, idproduk, jumlah) VALUES (:userid, :idproduk, 1)")
            ->execute([
                ':userid' => $userid,
                ':idproduk' => $idProduk
            ]);
    }

    // Redirect agar tidak double-submit saat refresh
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Wishlist Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
    <style>
        .wishlist-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.05);
            padding: 20px;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .wishlist-card:hover {
            transform: scale(1.02);
        }

        .wishlist-card h5 {
            color: #12606e;
            font-weight: 600;
        }

        .btn-remove {
            border: none;
            background-color: transparent;
            color: #dc3545;
        }

        .btn-remove:hover {
            color: #a30000;
        }

        .wishlist-price {
            font-size: 1.1rem;
            font-weight: 500;
            color: #444;
        }
    </style>
</head>
<body>
<div class="container py-5">
    <h3 class="mb-4">Wishlist Saya</h3>

    <?php
    if (!isset($_SESSION['wishlist']) || count($_SESSION['wishlist']) == 0): ?>
        <div class="alert alert-info">Wishlist Anda masih kosong.</div>
    <?php else:
        foreach ($_SESSION['wishlist'] as $idProduk):
            $stmt = $conn->prepare("SELECT * FROM tb_produk WHERE idproduk = :idproduk");
            $stmt->bindParam(':idproduk', $idProduk);
            $stmt->execute();
            $produk = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($produk): ?>
                <div class="wishlist-card row align-items-center">
                    <div class="col-md-2 col-4">
                        <img src="../gbrproject/<?= htmlspecialchars($produk['img']) ?>" alt="<?= $produk['nama'] ?>" class="img-fluid rounded">
                    </div>
                    <div class="col-md-7 col-8">
                        <h5><?= htmlspecialchars($produk['nama']) ?></h5>
                        <p class="wishlist-price">IDN <?= number_format($produk['harga'], 0, ',', '.') ?></p>
                    </div>
                    <div class="col-md-3 text-end">
                        <a href="hapus_wishlist.php?id=<?= $produk['idproduk'] ?>" class="btn btn-remove" title="Hapus dari Wishlist">
                            <i class="fas fa-heart-broken fa-lg"></i> Hapus
                        </a>
                        <a href="?add_to_cart=<?= $produk['idproduk'] ?>" class="btn btn-icon" title="Tambah ke Keranjang">
                            <i class="fas fa-shopping-cart" style="font-size: 20px; color: #12606e;"></i>
                            </a>
                    </div>
                </div>
            <?php endif;
        endforeach;
    endif;
    ?>
           <a href="../index2.php" class="btn btn-info">Kembali</a>
</div>
</body>
</html>
