<?php
session_start();
include_once __DIR__ . '/../lib/config.php'; // Pastikan BASE_URL sudah didefinisikan di sini
?>

<h2 class="text-center m-4 h2 text-bold mb-5 mt-5" style="font-family: font1;">GROCERY STORE</h2>

<hr style="background-color: rgb(41, 118, 139); border: 2px; height: 2px; margin-top: 40px;">

<nav class="navbar navbar-expand-sm mb-2">
  <div style="font-family: font1;" class="container-fluid sticky-top mb-3">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link text-dark" href="<?= BASE_URL ?>index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="<?= BASE_URL ?>index2.php">Product</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="<?= BASE_URL ?>index3.php">Contact</a>
      </li>
    </ul>

    <div class="d-flex gap-4 align-items-center">
      <!-- Cart -->
      <div class="text-center">
        <a href="<?= BASE_URL ?>modul/cart.php" class="icon-link">
          <i class="fas fa-shopping-cart" style="font-size: 20px; color: #12606e;"></i>
          <div>Cart</div>
        </a>
      </div>

      <!-- Wishlist -->
      <div class="text-center">
        <a href="<?= BASE_URL ?>modul/wishlist.php" class="icon-link">
          <i class="fas fa-heart" style="font-size: 20px; color: #12606e;"></i>
          <div>Wishlist</div>
        </a>
      </div>

      <!-- Profil or Login -->
      <div class="text-center">
        <?php if (isset($_SESSION['username'])): ?>
          <a href="<?= BASE_URL ?>modul/profil.php" style="text-decoration: none;" class="icon-link">
            <i class="fas fa-user-circle" style="font-size: 20px; color: #12606e;"></i>
            <div>Profil</div>
          </a>
        <?php else: ?>
          <a href="<?= BASE_URL ?>login.php" style="text-decoration: none;" class="icon-link">
            <i class="fas fa-sign-in-alt" style="font-size: 20px; color: #12606e;"></i>
            <div>Login</div>
          </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<!-- CSS -->
<style>
  .icon-link {
    text-decoration: none;
    color: inherit;
    display: flex;
    flex-direction: column;
    align-items: center;
    transition: color 0.3s ease;
  }

  .icon-link:hover {
    color: #00cc00; /* Ganti warna ketika di-hover */
  }

  .icon-link i {
    transition: transform 0.2s ease;
  }

  .icon-link:hover i {
    transform: scale(1.2); /* Membesarkan ikon sedikit saat di-hover */
  }

  .icon-link div {
    font-size: 12px;
    color: #12606e;
  }

  .icon-link:hover div {
    color: #00cc00; /* Mengubah warna text saat di-hover */
  }
</style>
