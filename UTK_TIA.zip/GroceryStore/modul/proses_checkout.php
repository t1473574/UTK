
<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    header("Location: ../login.php"); // ganti dengan path login kamu jika berbeda
    if (empty($user['nama']) || empty($user['alamat']) || empty($user['nohp'])) {
    echo "<script>alert('silahkan lengkapi profil'); window.location.href='profil.php';</script>";
    exit;
}
}



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['idproduk'])) {
    // Ambil data produk dari POST
    $idproduk = $_POST['idproduk'];
    $harga = isset($_POST['harga']) ? (float) $_POST['harga'] : 0;
    $jumlah = isset($_POST['jumlah']) ? (int) $_POST['jumlah'] : 0;
    $total = $harga * $jumlah;
    

    // Ambil info produk dari database
    $stmt = $conn->prepare("SELECT * FROM tb_produk WHERE idproduk = :idproduk");
    $stmt->execute([':idproduk' => $idproduk]);
    $produk = $stmt->fetch(PDO::FETCH_ASSOC);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['konfirmasi'])) {
    // Simpan transaksi ke database
    $userid = $_SESSION['userid'];
    $total = $_POST['total'];
    $idproduk = $_POST['idproduk'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];

    // Insert ke tb_order
    $stmt = $conn->prepare("INSERT INTO tb_order (userid, total, tanggal) VALUES (:userid, :total, NOW())");
    $stmt->execute([':userid' => $userid, ':total' => $total]);
    $idorder = $conn->lastInsertId();

    // Insert ke tb_order_detail
    $stmtDetail = $conn->prepare("INSERT INTO tb_order_detail (idorder, idproduk, jumlah, harga) 
        VALUES (:idorder, :idproduk, :jumlah, :harga)");
    $stmtDetail->execute([
        ':idorder' => $idorder,
        ':idproduk' => $idproduk,
        ':jumlah' => $jumlah,
        ':harga' => $harga
    ]);

    echo "<script>alert('Pembelian berhasil!'); window.location.href='riwayat_order.php';</script>";
    exit;
} else {
    die("Akses tidak valid.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Konfirmasi Pembelian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card shadow rounded-4">
                <div class="card-header bg-success text-white rounded-top-4">
                    <h4 class="mb-0">🛍️ Rincian Pembelian</h4>
                </div>
                <div class="card-body">
                    <p><strong>🧾 Nama Produk:</strong> <?= htmlspecialchars($produk['nama']) ?></p>
                    <p><strong>💸 Harga Satuan:</strong> Rp <?= number_format($harga, 0, ',', '.') ?></p>
                    <hr>
                    <p><strong>💰 Total Bayar:</strong> <span class="text-success fs-5">Rp <?= number_format($total, 0, ',', '.') ?></span></p>
                      <!-- Metode Pembayaran -->
        <div class="mb-3">
            <label class="form-label"><strong>💳 Metode Pembayaran:</strong></label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="metode" value="COD" id="cod" checked>
                <label class="form-check-label" for="cod">
                    Bayar di Tempat (COD)
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="metode" value="QRIS" id="qris">
                <label class="form-check-label" for="qris">
                    Pembayaran via QRIS
                </label>
            </div>
        </div>
                    <form method="POST" action="checkout_singel.php" class="d-inline-block w-100">
    <p><strong>🔢 Jumlah:
        <input type="number" name="jumlah" value="1" min="1" class="form-control form-control-sm w-25" style="margin-right: 10px;">
    </p>
    
    <input type="hidden" name="idproduk" value="<?= $produk['idproduk'] ?>"> <!-- ID produk dinamis -->
    <input type="hidden" name="harga" value="<?= $produk['harga'] ?>"> <!-- Harga produk dinamis -->

    <!-- Tombol Konfirmasi Pembelian -->
    <button type="submit" name="konfirmasi" class="btn btn-success w-100 rounded-pill mt-3 fw-semibold">
        ✅ Konfirmasi Pembelian
    </button> 

    <!-- Tombol Kembali ke Produk -->
    <a href="../index2.php" class="btn btn-outline-secondary w-100 rounded-pill mt-2">
        🔙 Kembali ke Produk
    </a>
</form>


                  
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

