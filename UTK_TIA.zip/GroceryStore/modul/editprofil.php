<?php
session_start();
require '../lib/koneksi.php';

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT * FROM tb_user WHERE username = :username");
$stmt->bindParam(':username', $username);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$success = $error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = htmlspecialchars($_POST['fullname']);
    $no_hp = htmlspecialchars($_POST['no_hp']);
    $alamat = htmlspecialchars($_POST['alamat']);
    $uploadOk = true;
    $img_url = $user['img_url'];

    // Jika ada file diunggah
    if ($_FILES['foto']['name']) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        $max_size = 2 * 1024 * 1024; // 2MB
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $size = $_FILES['foto']['size'];

        if (!in_array($ext, $allowed_ext)) {
            $error = "Format gambar harus JPG, JPEG, PNG, atau GIF.";
            $uploadOk = false;
        } elseif ($size > $max_size) {
            $error = "Ukuran gambar maksimal 2MB.";
            $uploadOk = false;
        } else {
            $new_name = uniqid() . '.' . $ext;
            $destination = realpath('../gbrproject') . '/' . $new_name;
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $destination)) {
                $img_url = $new_name;
            } else {
                $error = "Gagal mengunggah gambar.";
                $uploadOk = false;
            }
        }
    }

    if ($uploadOk) {
        $stmt = $conn->prepare("UPDATE tb_user SET fullname = :fullname, no_hp = :no_hp, alamat = :alamat, img_url = :img_url WHERE username = :username");
        $stmt->execute([
            'fullname' => $fullname,
            'no_hp' => $no_hp,
            'alamat' => $alamat,
            'img_url' => $img_url,
            'username' => $username
        ]);
        
        // Redirect ke profil setelah sukses
        header("Location: profil.php");
        exit();
    }
    
}
?>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<div class="container py-5">
    <div class="card shadow-lg border-0 rounded-4">
        <div class="card-header text-white rounded-top-4" style="background: linear-gradient(90deg, #12606e, #17a2b8);">
            <h4 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Edit Profil</h4>
        </div>
        <div class="card-body p-4">
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php elseif ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($user['fullname']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">No HP</label>
                    <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($user['no_hp']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($user['alamat']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Foto Profil (opsional)</label>
                    <input type="file" name="foto" class="form-control">
                    <?php if (!empty($user['img_url'])): ?>
                        <img src="../gbrproject/<?= htmlspecialchars($user['img_url']) ?>" class="mt-3 rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                    <?php endif; ?>
                </div>
                <div class="d-flex gap-2 justify-content-end mt-4">
                 <a href="profil.php" class="btn btn-outline-secondary px-4">
                <i class="bi bi-x-circle me-1"></i> Batal
                  </a>
               <button type="submit" class="btn btn-success px-4">
                 <i class="bi bi-check-circle me-1"></i> Simpan
                 </button>
              </div>
            </form>
        </div>
    </div>
</div>
<style>
    .btn {
        font-weight: 600;
        border-radius: 0.5rem;
        transition: 0.3s ease;
    }

    .btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 3px 10px rgba(0,0,0,0.15);
    }
</style>

