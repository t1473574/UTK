<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    die("Anda harus login terlebih dahulu.");
}

$userid = $_SESSION['userid'];

$stmt = $conn->prepare("SELECT * FROM tb_order WHERE userid = :userid ORDER BY tanggal DESC");
$stmt->execute([':userid' => $userid]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .order-card {
            border-left: 5px solid #00cc00;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            padding: 20px;
            margin-bottom: 20px;
            background-color: white;
        }
        .order-id {
            font-weight: bold;
            color: #12606e;
        }
        .order-total {
            font-size: 1.2rem;
            color: #009900;
        }
        .order-date {
            color: #666;
            font-size: 0.9rem;
        }
        .btn-detail {
            background-color: #12606e;
            color: white;
            border-radius: 20px;
            padding: 5px 15px;
            text-decoration: none;
        }
        .btn-detail:hover {
            background-color: #0f4f58;
        }
        body {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-2">Riwayat Pesanan Anda</h2>
    <a href="../index2.php" class="btn btn-info mb-4">Kembali</a>

    <?php if (count($orders) > 0): ?>
        <?php foreach ($orders as $order): ?>
            <div class="order-card d-flex justify-content-between align-items-center">
                <div>
                    <div class="order-id">Order ID: #<?= $order['idorder'] ?></div>
                    <div class="order-date">Tanggal: <?= date('d-m-Y H:i', strtotime($order['tanggal'])) ?></div>
                    <div class="order-total">Total: Rp<?= number_format($order['total'], 0, ',', '.') ?></div>
                </div>
                <a href="order_detail.php?id=<?= $order['idorder'] ?>" class="btn-detail">Lihat Detail</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="alert alert-info">Belum ada pesanan yang dilakukan.</div>
    <?php endif; ?>
</div>
</body>
</html>
