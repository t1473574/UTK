<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    header("Location: login.php"); // ganti dengan path login kamu jika berbeda
}

$userid = $_SESSION['userid'];

$idproduk = $_POST['idproduk'];
$jumlah = $_POST['jumlah'];
$harga = $_POST['harga'];
$total = $harga * $jumlah;

// Simpan ke tb_order
$stmt = $conn->prepare("INSERT INTO tb_order (userid, total, tanggal) VALUES (:userid, :total, NOW())");
$stmt->execute([
    ':userid' => $userid,
    ':total' => $total
]);

$idorder = $conn->lastInsertId();

// Simpan ke tb_order_detail
$stmtDetail = $conn->prepare("
    INSERT INTO tb_order_detail (idorder, idproduk, jumlah, harga) 
    VALUES (:idorder, :idproduk, :jumlah, :harga)
");
$stmtDetail->execute([
    ':idorder' => $idorder,
    ':idproduk' => $idproduk,
    ':jumlah' => $jumlah,
    ':harga' => $harga
]);

echo "<script>alert('Pembelian berhasil!'); window.location.href='riwayat_order.php';</script>";
