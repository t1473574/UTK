<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    die("Anda harus login terlebih dahulu.");
}

// Handle proses checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout_all'])) {
    $userid = $_SESSION['userid'];
    $idproduk = $_POST['idproduk'];   // array
    $harga = $_POST['harga'];         // array
    $jumlah = $_POST['jumlah'];       // array

    // Hitung total keseluruhan
    $total = 0;
    for ($i = 0; $i < count($idproduk); $i++) {
        if (is_numeric($harga[$i]) && is_numeric($jumlah[$i])) {
            $total += $harga[$i] * $jumlah[$i];
        }
    }

    // Simpan ke tb_order
    $stmt = $conn->prepare("INSERT INTO tb_order (userid, total, tanggal) VALUES (:userid, :total, NOW())");
    $stmt->execute([':userid' => $userid, ':total' => $total]);
    $idorder = $conn->lastInsertId();

    // Simpan ke tb_order_detail
    $stmtDetail = $conn->prepare("INSERT INTO tb_order_detail (idorder, idproduk, jumlah, harga)
        VALUES (:idorder, :idproduk, :jumlah, :harga)");

    for ($i = 0; $i < count($idproduk); $i++) {
        $stmtDetail->execute([
            ':idorder' => $idorder,
            ':idproduk' => $idproduk[$i],
            ':jumlah' => $jumlah[$i],
            ':harga' => $harga[$i]
        ]);
    }

    // Hapus isi keranjang
    $conn->prepare("DELETE FROM tb_cart WHERE userid = :userid")->execute([':userid' => $userid]);

    echo "<script>alert('Checkout berhasil!'); window.location.href='riwayat_order.php';</script>";
    exit;
}
?>

<!-- TAMPILAN KONFIRMASI PEMBELIAN -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Konfirmasi Pembelian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow rounded-4">
                <div class="card-header bg-success text-white rounded-top-4">
                    <h4 class="mb-0">🛍️ Konfirmasi Pembelian Semua Barang</h4>
                </div>
                <div class="card-body">

                    <form method="POST" action="">
                        <?php
                        // Ambil isi keranjang untuk ditampilkan
                        $userid = $_SESSION['userid'];
                        $stmt = $conn->prepare("SELECT c.idproduk, p.nama, p.harga, c.jumlah 
                            FROM tb_cart c 
                            JOIN tb_produk p ON c.idproduk = p.idproduk 
                            WHERE c.userid = :userid");
                        $stmt->execute([':userid' => $userid]);
                        $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        $total = 0;
                        foreach ($cartItems as $item):
                            $subtotal = $item['harga'] * $item['jumlah'];
                            $total += $subtotal;
                        ?>
                            <div class="mb-3 border-bottom pb-2">
                                <p><strong>🧾 <?= htmlspecialchars($item['nama']) ?></strong></p>
                                <p>💸 Harga: Rp <?= number_format($item['harga'], 0, ',', '.') ?></p>
                                <p>🔢 Jumlah: <?= $item['jumlah'] ?></p>
                                <input type="hidden" name="idproduk[]" value="<?= $item['idproduk'] ?>">
                                <input type="hidden" name="harga[]" value="<?= $item['harga'] ?>">
                                <input type="hidden" name="jumlah[]" value="<?= $item['jumlah'] ?>">
                            </div>
                        <?php endforeach; ?>

                        <hr>
                        <p><strong>💰 Total Bayar:</strong> <span class="text-success fs-5">Rp <?= number_format($total, 0, ',', '.') ?></span></p>

                        <!-- Metode Pembayaran -->
                        <div class="mb-3">
                            <label class="form-label"><strong>💳 Metode Pembayaran:</strong></label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="metode" value="COD" id="cod" checked>
                                <label class="form-check-label" for="cod">Bayar di Tempat (COD)</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="metode" value="QRIS" id="qris">
                                <label class="form-check-label" for="qris">Pembayaran via QRIS</label>
                            </div>
                        </div>

                        <button type="submit" name="checkout_all" class="btn btn-success w-100 rounded-pill fw-semibold">
                             Konfirmasi & Checkout Semua
                        </button>

                        <a href="../index2.php" class="btn btn-outline-secondary w-100 rounded-pill mt-2">
                            🔙 Kembali ke Produk
                        </a>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
