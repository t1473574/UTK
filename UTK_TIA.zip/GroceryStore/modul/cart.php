<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    header("Location: ../login.php"); // ganti dengan path login kamu jika berbeda
}

$userid = $_SESSION['userid'];

// Ambil data keranjang dengan join ke produk
$sql = "
    SELECT produk.nama, produk.harga, tb_cart.jumlah, produk.idproduk
    FROM tb_cart AS tb_cart
    JOIN tb_produk AS produk ON tb_cart.idproduk = produk.idproduk
    WHERE tb_cart.userid = :userid
";

$stmt = $conn->prepare($sql);
$stmt->execute([':userid' => $userid]);
$items = $stmt->fetchAll();

$total = 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .btn-delete {
            background-color: #f8d7da;
            color: #dc3545;
            border: none;
            padding: 6px 10px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-delete:hover {
            background-color: #dc3545;
            color: white;
        }

        .table thead {
            background-color: #e9ecef;
        }

        .jumlah-badge {
            background-color: #12606e;
            padding: 6px 12px;
            border-radius: 12px;
            color: white;
            font-weight: 500;
        }

        .cart-title {
            color: #12606e;
            border-left: 5px solid #00cc00;
            padding-left: 10px;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="cart-title">Keranjang Belanja</h2>
    <table class="table table-bordered mt-3">
        <thead class="table-light">
        <tr>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $index => $item): 
            $subtotal = $item['harga'] * $item['jumlah'];
            $total += $subtotal;
        ?>
        <tr class="align-middle">
            <td><?= htmlspecialchars($item['nama']) ?></td>
            <td>Rp<?= number_format($item['harga'], 0, ',', '.') ?></td>
            <td><?= $item['jumlah'] ?></td>
            <td>Rp<?= number_format($subtotal, 0, ',', '.') ?></td>
            <td>
                <a href="hapus_cart.php?idproduk=<?= $item['idproduk'] ?>" class="btn btn-outline-danger btn-sm rounded-pill px-3" onsubmit="return confirm('Yakin ingin menghapus item ini?')"> <i class="fas fa-xmark me-1"></i> Hapus</a>
            </td>
        </tr>

        <!-- Hidden inputs for checkout -->
         <form method="POST" action="proses_cart.php">
                 <input type="hidden" name="idproduk[]" value="<?= $item['idproduk'] ?>">
        <input type="hidden" name="harga[]" value="<?= $item['harga'] ?>">
        <input type="hidden" name="jumlah[]" value="<?= $item['jumlah'] ?>">
        <?php endforeach; ?>
        <tr class="table-light fw-bold">
            <td colspan="3" class="text-end">Total</td>
            <td>Rp<?= number_format($total, 0, ',', '.') ?></td>
            <td></td>
        </tr>
        </tbody>
    </table>
    <button type="submit" class="btn btn-success">🛒 Checkout Semua</button>
    <a href="riwayat_order.php" class="btn btn-primary">Riwayat Pemesanan</a>
    <a href="../index2.php" class="btn btn-info">Kembali</a>
 </form>
</div>
</body>
</html>
