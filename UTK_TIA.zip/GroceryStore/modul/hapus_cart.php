<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    die("Anda harus login terlebih dahulu.");
}

$userid = $_SESSION['userid'];

if (isset($_GET['idproduk'])) {
    $idproduk = $_GET['idproduk'];

    // Hapus berdasarkan userid + idproduk
    $sql = "DELETE FROM tb_cart WHERE userid = :userid AND idproduk = :idproduk";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':userid' => $userid,
        ':idproduk' => $idproduk
    ]);

    header("Location: cart.php");
    exit;
} else {
    die("ID produk tidak valid.");
}
