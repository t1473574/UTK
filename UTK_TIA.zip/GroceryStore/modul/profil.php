<?php
session_start();
require '../lib/koneksi.php';
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}



$username = $_SESSION['username'];

$stmt = $conn->prepare("SELECT * FROM tb_user WHERE username = :username");
$stmt->bindParam(':username', $username);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<div class="container py-5">
    <div class="card shadow-lg border-0 rounded-4">
        <div class="card-header text-white rounded-top-4" style="background: linear-gradient(90deg, #12606e, #1d9f94);">
            <h4 class="mb-0"><i class="bi bi-person-circle me-2"></i>Profil Pengguna</h4>
        </div>
        <div class="card-body p-5">
            <div class="row align-items-center">
                <div class="col-md-4 text-center">
                    <img src="../gbrproject/<?= $user['img_url']?>" 
                         alt="Foto Profil" 
                         class="img-fluid rounded-circle shadow-sm mb-3" 
                         style="width: 150px; height: 150px; object-fit: cover;">
                </div>
                <div class="col-md-8">
                <ul class="list-group list-group-flush rounded-3">
    <li class="list-group-item d-flex align-items-center bg-light">
        <i class="bi bi-person-fill text-primary me-3 fs-5"></i>
        <div>
            <div class="fw-bold">Username</div>
            <div><?= htmlspecialchars($user['username']) ?></div>
        </div>
    </li>
    <li class="list-group-item d-flex align-items-center bg-light">
        <i class="bi bi-person text-success me-3 fs-5"></i>
        <div>
            <div class="fw-bold">Full Name</div>
            <div><?= htmlspecialchars($user['fullname']) ?></div>
        </div>
    </li>
    <li class="list-group-item d-flex align-items-center bg-light">
        <i class="bi bi-phone text-warning me-3 fs-5"></i>
        <div>
            <div class="fw-bold">Nomor HP</div>
            <div><?= htmlspecialchars($user['no_hp']) ?></div>
        </div>
    </li>
    <li class="list-group-item d-flex align-items-center bg-light">
        <i class="bi bi-geo-alt-fill text-danger me-3 fs-5"></i>
        <div>
            <div class="fw-bold">Alamat</div>
            <div><?= htmlspecialchars($user['alamat'] ?? '-') ?></div>
        </div>
    </li>
</ul>

                    
                    <!-- Tombol Edit Profil dan Ganti Password berada di samping -->
                    <div class="row mt-4 gx-2 gy-2">
    <div class="col-auto">
        <a href="editprofil.php" class="btn btn-info px-4 py-2 rounded-3 shadow-sm hover-shadow">
            <i class="bi bi-pencil-square me-2"></i>Edit Profil
        </a>
    </div>
    <div class="col-auto">
        <a href="gantipw.php" class="btn btn-danger px-4 py-2 rounded-3 shadow-sm hover-shadow">
            <i class="bi bi-key-fill me-2"></i>Ganti Password
        </a>
    </div>
    <div class="col-auto">
        <a href="logout.php" class="btn btn-warning px-4 py-2 rounded-3 shadow-sm hover-shadow">
            <i class="bi bi-box-arrow-right me-2"></i>Log Out
        </a>
    </div>
    <div class="col-auto">
        <a href="../index.php" class="btn btn-secondary px-4 py-2 rounded-3 shadow-sm hover-shadow">
            <i class="bi bi-house-door-fill me-2"></i>Kembali ke Beranda
        </a>
    </div>
</div>


                </div>
            </div>
        </div>
    </div>
</div>

<!-- Custom CSS untuk Hover Effects dan Background -->
<style>
    .hover-shadow {
        transition: all 0.3s ease;
    }
    .hover-shadow:hover {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        transform: translateY(-2px);
    }
    .btn-info, .btn-danger, .btn-warning {
        font-size: 16px;
        font-weight: 600;
    }
    .card-body {
        background-color: #f1f3f5; /* Background halaman profil */
    }
    .list-group-item {
        background-color: #ffffff !important; /* Warna background yang lebih terang pada list */
    }
    /* Efek hover pada tombol untuk memberikan warna terang */
    .btn-info:hover {
        background-color: #0c7c8a;
    }
    .btn-danger:hover {
        background-color: #c82333;
    }
    .btn-warning:hover {
        background-color: #e0a800;
    }
    /* Membuat tombol lebih kotak dan proporsional */
    .rounded-3 {
        border-radius: 8px !important; /* Membuat sudut lebih kotak */
    }
    .btn-lg {
        height: 50px; /* Menetapkan tinggi tombol agar lebih sesuai */
    }
    .w-100 {
        width: 100%; /* Tombol memenuhi seluruh lebar kontainer tapi lebih kotak */
    }
</style>
