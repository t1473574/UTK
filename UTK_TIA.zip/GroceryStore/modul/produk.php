<?php

// Fungsi untuk menambahkan produk ke keranjang
if (isset($_GET['add_to_cart'])) {
    if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit;
    if (empty($user['nama']) || empty($user['alamat']) || empty($user['nohp'])) {
    echo "<script>alert('silahkan lengkapi profil'); window.location.href='modul/profil.php';</script>";
    exit;
}
}

// Ambil data user
$stmtUser = $conn->prepare("SELECT * FROM tb_user WHERE userid = :id");
$stmtUser->execute([':id' => $_SESSION['userid']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Cek kelengkapan profil

    
    $idProduk = $_GET['add_to_cart'];
    $userid = $_SESSION['userid'];

    // Cek apakah produk sudah ada di keranjang
    $stmtCek = $conn->prepare("SELECT * FROM tb_cart WHERE userid = :userid AND idproduk = :idproduk");
    $stmtCek->execute([
        ':userid' => $userid,
        ':idproduk' => $idProduk
    ]);

    if ($stmtCek->rowCount() > 0) {
        // Jika sudah ada, update jumlah +1
        $conn->prepare("UPDATE tb_cart SET jumlah = jumlah + 1 WHERE userid = :userid AND idproduk = :idproduk")
            ->execute([
                ':userid' => $userid,
                ':idproduk' => $idProduk
            ]);
    } else {
        // Jika belum ada, insert baru
        $conn->prepare("INSERT INTO tb_cart (userid, idproduk, jumlah) VALUES (:userid, :idproduk, 1)")
            ->execute([
                ':userid' => $userid,
                ':idproduk' => $idProduk
            ]);
    }

    // Redirect agar tidak double-submit saat refresh
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Fungsi untuk menambahkan produk ke wishlist
if (isset($_GET['add_to_wishlist'])) {
   if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit;
    if (empty($user['nama']) || empty($user['alamat']) || empty($user['nohp'])) {
    echo "<script>alert('silahkan lengkapi profil'); window.location.href='modul/profil.php';</script>";
    exit;
}
}

$stmtUser = $conn->prepare("SELECT * FROM tb_user WHERE userid = :id");
$stmtUser->execute([':id' => $_SESSION['userid']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);


    $idProduk = $_GET['add_to_wishlist'];

    if (!isset($_SESSION['wishlist'])) {
        $_SESSION['wishlist'] = [];
    }

    if (!in_array($idProduk, $_SESSION['wishlist'])) {
        $_SESSION['wishlist'][] = $idProduk;
    }
}


// Mengambil kategori produk
$stmtKategori = $conn->prepare("SELECT * FROM tb_kate");
$stmtKategori->execute();
$kategoriList = $stmtKategori->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="container py-5">
<?php 
$idkateTerpilih = isset($_GET['kategori']) ? $_GET['kategori'] : null;


foreach ($kategoriList as $kategori):
    $idkate = $kategori['idkate'];
    $titleKategori = $kategori['title'];

    // Kalau sedang filter kategori, dan bukan kategori ini, skip
    if ($idkateTerpilih && $idkateTerpilih != $idkate) {
        continue;
    }
    $stmtProduk = $conn->prepare("SELECT * FROM tb_produk WHERE idkate = :idkate");
    $stmtProduk->execute([':idkate' => $idkate]);
    $produkList = $stmtProduk->fetchAll(PDO::FETCH_ASSOC);

    if (count($produkList) > 0): ?>
        <h4 class="section-title"><?= htmlspecialchars($titleKategori) ?></h4>
        <div class="row mb-5">
            <?php foreach ($produkList as $produk): ?>
                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="product-card d-flex flex-md-row flex-column align-items-center">
                        <img src="gbrproject/<?= $produk['img'] ?>" class="product-img me-md-4 mb-3 mb-md-0" alt="<?= $produk['nama'] ?>">
                        <div class="product-info text-md-start text-center">
                            <h5><?= htmlspecialchars($produk['nama']) ?></h5>
                            <p class="harga">IDN <?= number_format($produk['harga'], 0, ',', '.') ?></p>

                    
                            <a href="?add_to_cart=<?= $produk['idproduk'] ?>" class="btn btn-icon" title="Tambah ke Keranjang">
                            <i class="fas fa-shopping-cart" style="font-size: 20px; color: #12606e;"></i>
                            </a>
                       

                            <!-- Add to Wishlist tetap pakai session -->
                            <a href="?add_to_wishlist=<?= $produk['idproduk'] ?>" class="btn btn-icon" title="Tambah ke Wishlist">
                                <i class="fas fa-heart" style="font-size: 20px; color: #12606e;"></i>
                            </a>

                            <form method="POST" action="modul/proses_checkout.php" class="d-inline-block mt-2">
                            <input type="hidden" name="idproduk" value="<?= $produk['idproduk'] ?>"> <!-- ID produk dinamis -->
                            <div class="d-flex align-items-center">
                            <input type="number" name="jumlah" value="1" min="1" class="form-control form-control-sm w-25" style="margin-right: 10px;"> <!-- Ukuran input jumlah -->
                            <input type="hidden" name="harga" value="<?= $produk['harga'] ?>"> <!-- Harga produk dinamis -->
                            <button type="submit" class="btn btn-success btn-sm">Buy Now</button>
                            </div>
                            </form>
                            
                           

                    
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif;
endforeach; ?>
</div>

<!-- Custom CSS untuk Ikon dan Button -->
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #f8f9fa;
        color: #333;
    }

    .section-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1.5rem;
        color: #12606e;
        border-left: 5px solid #00cc00;
        padding-left: 10px;
    }

    /* Card produk besar */
    .product-card {
        background-color: #ffffff;
        border-radius: 12px;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.05);
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(255, 255, 255, 0.1);
    }

    /* Gambar lebih besar di kiri */
    .product-img {
        width: 180px;
        height: 180px;
        object-fit: contain;
        background-color: #f4f4f4;
        border-radius: 10px;
    }

    /* Info produk besar */
    .product-info h5 {
        font-weight: 700;
        font-size: 20px;
        color: #12606e;
        margin-bottom: 10px;
    }

    .product-info .harga {
        font-size: 16px;
        color: #444;
        margin-bottom: 15px;
    }

    /* Tombol dengan ikon */
    .btn-icon {
        font-size: 20px;
        padding: 10px;
        margin-right: 10px;
        border-radius: 50%;
        background-color: #f0f0f0;
        color: #12606e;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .btn-icon:hover {
        background-color:rgb(166, 207, 214);
        color: white;
    }

    /* Tombol BUY */
    .btn-buy {
        background-color: #00cc00;
        color: white;
        font-weight: bold;
        padding: 8px 20px;
        border-radius: 25px;
        text-transform: uppercase;
        font-size: 14px;
        border: none;
        transition: background-color 0.2s ease;
    }

    .btn-buy:hover {
        background-color: #009900;
    }
</style>
