<?php
session_start();

if (isset($_GET['id'])) {
    $idProduk = $_GET['id'];

    // Cek apakah wishlist ada
    if (isset($_SESSION['wishlist'])) {
        // Cari dan hapus ID produk dari session wishlist
        $index = array_search($idProduk, $_SESSION['wishlist']);
        if ($index !== false) {
            unset($_SESSION['wishlist'][$index]);
            $_SESSION['wishlist'] = array_values($_SESSION['wishlist']); // Reset index
        }
    }
}

// Redirect kembali ke halaman wishlist
header("Location: wishlist.php");
exit;
