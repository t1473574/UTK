<?php
session_start();
require_once '../lib/koneksi.php';

if (!isset($_SESSION['userid'])) {
    die("Anda harus login terlebih dahulu.");
}

if (!isset($_GET['id'])) {
    die("ID order tidak ditemukan.");
}

$idorder = $_GET['id'];
$userid = $_SESSION['userid'];

// Validasi order milik user
$stmt = $conn->prepare("SELECT * FROM tb_order WHERE idorder = :idorder AND userid = :userid");
$stmt->execute([':idorder' => $idorder, ':userid' => $userid]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order tidak ditemukan.");
}

// Ambil detail produk
$stmtDetail = $conn->prepare("
    SELECT d.*, p.nama, p.img 
    FROM tb_order_detail d 
    JOIN tb_produk p ON d.idproduk = p.idproduk 
    WHERE d.idorder = :idorder
");
$stmtDetail->execute([':idorder' => $idorder]);
$items = $stmtDetail->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .item-img {
            width: 60px;
            height: 60px;
            object-fit: contain;
        }
        .table th, .table td {
            vertical-align: middle;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h3>Detail Order #<?= $order['idorder'] ?></h3>
    <p>Tanggal: <?= date('d-m-Y H:i', strtotime($order['tanggal'])) ?></p>
    <p>Total: <strong>Rp<?= number_format($order['total'], 0, ',', '.') ?></strong></p>

    <table class="table table-bordered mt-4">
        <thead class="table-light">
            <tr>
                <th>Produk</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td>
                        <img src="../gbrproject/<?= $item['img'] ?>" class="item-img me-2" alt="<?= $item['nama'] ?>">
                        <?= htmlspecialchars($item['nama']) ?>
                    </td>
                    <td>Rp<?= number_format($item['harga'], 0, ',', '.') ?></td>
                    <td><?= $item['jumlah'] ?></td>
                    <td>Rp<?= number_format($item['harga'] * $item['jumlah'], 0, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="riwayat_order.php" class="btn btn-secondary">Kembali</a>
</div>
</body>
</html>
