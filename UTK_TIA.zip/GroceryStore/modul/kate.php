<?php
include "lib/koneksi.php";

$sql = "SELECT idkate, title, img_url FROM tb_kate";
$stmt = $conn->prepare($sql);
$stmt->execute();

$categoryItems = '';
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $idkate = $row['idkate'];
    $title = htmlspecialchars($row['title']);
    $img = htmlspecialchars($row['img_url']);

    $categoryItems .= <<<HTML
    <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
        <div class="card ecom-card border-0 shadow-sm rounded-lg overflow-hidden position-relative">
            <div class="card-img-container">
                <a href="index2.php?kategori=$idkate">
                    <img src="gbrproject/$img" alt="$title" class="card-img-top" style="object-fit: cover; height: 200px;">
                </a>
            </div>
            <div class="card-body text-center mt-5">
                <a href="index2.php?kategori=$idkate" class="btn btn-primary w-100" style="font-family: font1;">$title</a>
            </div>
        </div>
    </div>
    HTML;
}
$conn = null;
?>

<!-- Tampilan Kategori Grid -->
<div class="container mt-2">
<h2 class="text-center m-4 h2 text-bold mb-5" style="font-family: font1;">Category</h2>
    <div class="row justify-content-center">
        <?php echo $categoryItems; ?>
    </div>
</div>

<style>
    /* Card untuk e-commerce */
    .ecom-card {
        height: 380px;
        border-radius: 10px;
        background-color: #ffffff;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    /* Gambar produk */
    .card-img-container {
        height: 60%;
        width: 100%;
        position: relative;
        background: #f5f5f5;
    }

    .card-img-top {
        width: 100%;
        height: 100%;
        transition: transform 0.3s ease;
    }

    /* Hover effect gambar */
    .ecom-card:hover .card-img-top {
        transform: scale(1.1);
    }

    /* Styling untuk body card */
    .card-body {
        padding: 1.25rem;
        background-color: #fff;
        position: relative;
        height: 40%;
        box-shadow: inset;
    }

    .card-body .card-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: #12606e;
        margin-bottom: 1rem;
    }

    /* Tombol View Details */
    .card-body .btn {
        font-size: 1rem;
        padding: 10px;
        font-weight: 600;
        background-color: #12606e;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .card-body .btn:hover {
        background-color: #0e4e53;
    }

    /* Hover effect untuk keseluruhan card */
    .ecom-card:hover {
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        transform: translateY(-5px);
    }

    /* Responsive untuk perangkat lebih kecil */
    @media (max-width: 767px) {
        .ecom-card {
            height: 400px;
        }

        .card-body .card-title {
            font-size: 1rem;
        }
    }
</style>
